
function showModal(roomName) {
  document.getElementById('modal-room-name').innerText = roomName;
  document.getElementById('modal').style.display = 'block';
}

function hideModal() {
  document.getElementById('modal').style.display = 'none';
}


